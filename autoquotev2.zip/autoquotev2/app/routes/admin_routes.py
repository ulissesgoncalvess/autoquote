from flask import Blueprint, render_template, request, redirect, url_for, session, flash, current_app
from app.models import UserModel
from werkzeug.security import generate_password_hash
from datetime import datetime

admin_bp = Blueprint('admin', __name__)

@admin_bp.before_request
def check_admin():
    if not session.get('is_admin'):
        flash('Acesso não autorizado.', 'error')
        return redirect(url_for('main.dashboard'))

@admin_bp.route('/admin/users')
def manage_users():
    users = UserModel.get_all_users()
    return render_template('admin/users.html', users=users)

@admin_bp.route('/admin/users/create', methods=['POST'])
def create_user():
    email = request.form.get('email')
    password = request.form.get('password')
    nome = request.form.get('nome')
    is_admin = request.form.get('is_admin') == 'on'
    
    try:
        UserModel.create_user(
            email=email,
            password_hash=generate_password_hash(password),
            nome=nome,
            is_admin=is_admin
        )
        flash('Usuário criado com sucesso!', 'success')
    except Exception as e:
        flash('Erro ao criar usuário.', 'error')
        current_app.logger.error(f"Erro criar usuário admin: {str(e)}")
    
    return redirect(url_for('admin.manage_users'))

@admin_bp.route('/admin/users/<user_id>/toggle', methods=['POST'])
def toggle_user(user_id):
    try:
        client = UserModel.get_client()
        user = UserModel.get_user_by_id(user_id)
        
        client.table('users').update({
            'is_active': not user['is_active'],
            'updated_at': datetime.utcnow().isoformat()
        }).eq('id', user_id).execute()
        
        flash('Status do usuário atualizado!', 'success')
    except Exception as e:
        flash('Erro ao atualizar usuário.', 'error')
    
    return redirect(url_for('admin.manage_users'))