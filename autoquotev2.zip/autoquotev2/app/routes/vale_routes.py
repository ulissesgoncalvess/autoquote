# app/routes/vale_routes.py
from flask import Blueprint, jsonify, send_file, request
import os, glob, threading, traceback, time

vale_bp = Blueprint('vale', __name__)

# ============================
# VARIÁVEIS DE STATUS
# ============================
status_robo = {
    "executando": False,
    "mensagem": "Pronto para executar",
    "progresso": 0,
}


# ============================
# FUNÇÃO: BUSCAR PLANILHAS
# ============================
def buscar_planilhas_vale():
    """Busca planilhas geradas pelo robô em /app/output"""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # /app
    output_dir = os.path.join(base_dir, 'output')

    if not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    arquivos = glob.glob(os.path.join(output_dir, "planilha_vale_*.xlsx"))
    arquivos.sort(key=os.path.getmtime, reverse=True)
    return arquivos


# ============================
# ROTA: STATUS DO ROBÔ
# ============================
@vale_bp.route('/status')
def vale_status():
    data = status_robo.copy()
    arquivos_vale = buscar_planilhas_vale()
    data["planilha_disponivel"] = len(arquivos_vale) > 0
    if arquivos_vale:
        data["arquivo_recente"] = os.path.basename(arquivos_vale[0])
    data["total_arquivos"] = len(arquivos_vale)
    return jsonify(data)


# ============================
# ROTA: EXECUTAR ROBÔ
# ============================
@vale_bp.route('/executar', methods=['POST'])
def vale_executar():
    if status_robo["executando"]:
        return jsonify({"erro": "Robô já está em execução"}), 400

    data = request.get_json() or {}
    data_coleta = data.get("data_coleta")

    if not data_coleta or len(data_coleta) != 6:
        return jsonify({"erro": "Data inválida. Use o formato DDMMAA"}), 400

    # Atualiza status inicial
    status_robo.update({
        "executando": True,
        "mensagem": f"🚀 Iniciando coleta para {data_coleta}...",
        "progresso": 0
    })

    # Executa em thread separada
    thread = threading.Thread(target=rodar_robo_vale, args=(data_coleta,))
    thread.daemon = True
    thread.start()

    return jsonify({"mensagem": "Robô iniciado com sucesso"})


# ============================
# ROTA: DOWNLOAD PLANILHA
# ============================
@vale_bp.route('/download')
def vale_download():
    try:
        arquivos_vale = buscar_planilhas_vale()
        if not arquivos_vale:
            return jsonify({"erro": "Nenhuma planilha encontrada. Execute o robô primeiro."}), 404

        arquivo_recente = arquivos_vale[0]
        caminho_absoluto = os.path.abspath(arquivo_recente)
        if not os.path.exists(caminho_absoluto):
            return jsonify({"erro": f"Arquivo não encontrado: {caminho_absoluto}"}), 404

        print(f"📦 Enviando planilha real: {caminho_absoluto}")
        return send_file(caminho_absoluto, as_attachment=True)

    except Exception as e:
        print(f"❌ Erro no download: {str(e)}")
        print(traceback.format_exc())
        return jsonify({"erro": f"Erro no download: {str(e)}"}), 500


# ============================
# FUNÇÃO PRINCIPAL DO ROBÔ
# ============================
def rodar_robo_vale(data_coleta):
    from app.services.vale_service import executar_robo_vale

    def log(msg, progresso=None):
        """Atualiza status global e imprime no console"""
        ts = time.strftime("%H:%M:%S")
        print(f"[{ts}] {msg}")
        status_robo["mensagem"] = msg
        if progresso is not None:
            status_robo["progresso"] = progresso

    try:
        log("🚀 Iniciando execução do robô Vale...", 5)
        resultado = executar_robo_vale(data_coleta, log_callback=log)

        log("💾 Salvando planilha gerada...", 90)
        log("✅ Execução concluída com sucesso!", 100)

        status_robo.update({
            "executando": False,
            "mensagem": f"✅ Execução concluída ({resultado.get('eventos_coletados', 0)} eventos coletados)",
            "progresso": 100
        })

        log(f"📊 Arquivo final: {resultado.get('arquivo', 'desconhecido')}")

    except Exception as e:
        erro_msg = f"❌ Erro durante execução: {str(e)}"
        print(traceback.format_exc())
        status_robo.update({
            "executando": False,
            "mensagem": erro_msg,
            "progresso": 0
        })
        log(erro_msg)
