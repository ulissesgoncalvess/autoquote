from flask import Blueprint, render_template, request, redirect, url_for, session, flash, current_app
from app.models import UserModel

profile_bp = Blueprint("profile", __name__)

@profile_bp.route("/", methods=["GET", "POST"])
def profile():
    if "user_id" not in session:
        return redirect(url_for("auth.login"))

    user_id = session["user_id"]
    vale_config = UserModel.get_user_vale_config(user_id)

    if request.method == "POST":
        vale_email = request.form.get("vale_email")
        vale_password = request.form.get("vale_password")

        try:
            UserModel.update_user_vale_config(user_id, vale_email, vale_password)
            flash("Configurações do Vale atualizadas com sucesso!", "success")
            return redirect(url_for("profile.profile"))
        except Exception as e:
            flash("Erro ao salvar configurações.", "error")
            current_app.logger.error(f"Erro ao salvar config Vale: {str(e)}")

    return render_template("profile.html", vale_config=vale_config)

@profile_bp.route("/execution-logs")
def execution_logs():
    if "user_id" not in session:
        return redirect(url_for("auth.login"))

    logs = UserModel.get_user_execution_logs(session["user_id"])
    return render_template("execution_logs.html", logs=logs)
