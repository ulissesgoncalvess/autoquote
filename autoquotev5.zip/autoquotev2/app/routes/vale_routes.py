import os
import glob
import time
import traceback
from flask import Blueprint, jsonify, send_file, request, session
from app.services.vale_service import executar_robo_vale_async

vale_bp = Blueprint("vale", __name__)

# ============================
# ESTADO DE EXECUÇÃO POR USUÁRIO
# ============================
status_usuarios = {}

def get_status_usuario(user_id):
    """Retorna ou inicializa o status do robô de um usuário específico"""
    if user_id not in status_usuarios:
        status_usuarios[user_id] = {
            "executando": False,
            "mensagem": "Pronto para executar",
            "progresso": 0,
        }
    return status_usuarios[user_id]


# ============================
# FUNÇÃO: BUSCAR PLANILHAS DO USUÁRIO
# ============================
def buscar_planilhas_vale(user_id):
    """Busca planilhas do usuário em /app/output/<user_id>/"""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # /app
    output_dir = os.path.join(base_dir, "output", str(user_id))

    if not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    arquivos = glob.glob(os.path.join(output_dir, "planilha_vale_*.xlsx"))
    arquivos.sort(key=os.path.getmtime, reverse=True)
    return arquivos


# ============================
# ROTA: STATUS DO ROBÔ
# ============================
@vale_bp.route("/status")
def vale_status():
    """Retorna o status da execução e as planilhas recentes do usuário"""
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"erro": "Usuário não autenticado."}), 401

    status = get_status_usuario(user_id).copy()
    arquivos_vale = buscar_planilhas_vale(user_id)

    status["planilha_disponivel"] = len(arquivos_vale) > 0
    status["planilhas"] = [os.path.basename(a) for a in arquivos_vale[:5]]
    if arquivos_vale:
        status["arquivo_recente"] = os.path.basename(arquivos_vale[0])
    status["total_arquivos"] = len(arquivos_vale)

    return jsonify(status)


# ============================
# ROTA: EXECUTAR ROBÔ
# ============================
@vale_bp.route("/executar", methods=["POST"])
def vale_executar():
    """Executa o robô do Vale para o usuário logado"""
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"erro": "Usuário não autenticado."}), 401

    data = request.get_json() or {}
    data_coleta = data.get("data_coleta")

    status = get_status_usuario(user_id)
    if status["executando"]:
        return jsonify({"erro": "Robô já está em execução"}), 400

    if not data_coleta or len(data_coleta) != 6:
        return jsonify({"erro": "Data inválida. Use o formato DDMMAA"}), 400

    status.update({
        "executando": True,
        "mensagem": f"🚀 Iniciando coleta para {data_coleta}...",
        "progresso": 0,
    })

    def log_callback(msg, progresso=None):
        ts = time.strftime("%H:%M:%S")
        print(f"[{ts}] [{user_id}] {msg}")
        status["mensagem"] = msg
        if progresso is not None:
            status["progresso"] = progresso

    executar_robo_vale_async(
        data_coleta=data_coleta,
        user_id=user_id,
        log_callback=log_callback
    )

    return jsonify({"mensagem": "Robô iniciado em segundo plano."}), 202


# ============================
# ROTA: DOWNLOAD PLANILHA
# ============================
@vale_bp.route("/download/<filename>")
def vale_download(filename):
    """Permite o usuário baixar uma planilha específica"""
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"erro": "Usuário não autenticado."}), 401

    try:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        user_output_dir = os.path.join(base_dir, "output", str(user_id))
        caminho_arquivo = os.path.join(user_output_dir, filename)

        if not os.path.exists(caminho_arquivo):
            return jsonify({"erro": f"Arquivo não encontrado: {filename}"}), 404

        print(f"📦 Enviando planilha do usuário {user_id}: {caminho_arquivo}")
        return send_file(caminho_arquivo, as_attachment=True)

    except Exception as e:
        print(f"❌ Erro no download: {e}")
        print(traceback.format_exc())
        return jsonify({"erro": f"Erro no download: {str(e)}"}), 500
# ============================
# FIM DO ARQUIVO